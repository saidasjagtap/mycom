# Lessons Learned from Old Build
**Extracted:** 2026-04-03

---

## Critical Bugs Found (NEVER repeat these)

### 1. Legacy Key Split — THE #1 BUG
**What happened:** `operational_dashboard.html` and `leadership_dashboard.html` used `pa_appsettings` for settings (accent, alias, meeting time, charts). But `admin_console.html` writes to `pa_settings`. This meant changes in Admin Console NEVER reflected on dashboards.

**Rule:** ALL pages must read/write from `pa_settings` ONLY. Never use `pa_appsettings`, `pa_theme`, or `pa_adminpass`.

### 2. Template Literal CSS Crash
**What happened:** Putting CSS functions like `blur(4px)` inside `${}` in template literals broke the entire JavaScript. The parser misreads the parentheses.

**Rule:** Extract CSS function values to variables FIRST, then reference the variable in the template literal.
```javascript
// BAD - crashes JS
html += `<span style="filter:${showCodes ? 'none' : 'blur(4px)'}">`;

// GOOD - safe
const blurVal = showCodes ? 'none' : 'blur(4px)';
html += `<span style="filter:${blurVal}">`;
```

### 3. Missing HTML Elements — Silent JS Crash
**What happened:** JS called `getElementById('someId')` but the element didn't exist in HTML. No error shown, but entire page broke silently.

**Rule:** Before making ANY JS change, audit all `getElementById` / `querySelector` calls against actual HTML element IDs. Add missing elements rather than removing JS references.

### 4. Chunk Fixes Breaking Other Files
**What happened:** Fixing a bug in one file without auditing others caused cascading failures because all pages share localStorage keys.

**Rule:** Always audit ALL files before and after every change. Never do partial fixes.

---

## Storage Key Architecture (from old build)

### Keys Actually Used

| Key | Old home.html | Old operational | Old leadership | Old admin_console | New Rule |
|-----|--------------|-----------------|----------------|-------------------|----------|
| pa_settings | READ | SHOULD READ | SHOULD READ | READ/WRITE | Single source of truth |
| pa_appsettings | - | READ (BUG!) | READ (BUG!) | - | REMOVE — migrate to pa_settings |
| pa_theme | - | READ (BUG!) | READ (BUG!) | - | REMOVE — use pa_settings.theme |
| pa_adminpass | - | READ (BUG!) | READ (BUG!) | - | REMOVE — use pa_settings.adminPass |
| pa_account | READ | READ | READ | READ/WRITE | Keep |
| pa_clusters | READ | READ/WRITE | READ | WRITE (import) | Keep |
| pa_towers | - | READ/WRITE | - | READ/WRITE | Keep — unify with pa_home_towers |
| pa_home_towers | READ/WRITE | - | - | - | REMOVE — use pa_towers |
| pa_statuses | - | READ/WRITE | READ | READ/WRITE | Keep |
| pa_admins | READ | READ | - | READ/WRITE | Keep |
| pa_announcements | READ/WRITE | - | - | - | Keep |
| pa_dashLinks | READ | - | - | READ/WRITE | Keep |
| pa_home_content | READ/WRITE | - | - | - | Keep |
| pa_lastExport | - | - | - | WRITE | Keep |

### sessionStorage Keys
| Key | Used By | Purpose |
|-----|---------|---------|
| pa_session | operational_dashboard | Tower/admin login session |
| pa_admin_session | admin_console | Admin console login |
| pa_show_codes | operational, admin | Tower code visibility toggle |

---

## Patterns Worth Keeping

### 1. Storage Layer (S object)
All old files used this clean pattern:
```javascript
const S = {
  get: k => { try { return JSON.parse(localStorage.getItem('pa_' + k)) } catch(e) { return null } },
  set: (k, v) => localStorage.setItem('pa_' + k, JSON.stringify(v)),
  remove: k => localStorage.removeItem('pa_' + k),
  keys: () => Object.keys(localStorage).filter(k => k.startsWith('pa_'))
};
```

### 2. CSS Variable Theming
Old files had a clean light/dark system via `[data-theme]` attribute on `<html>`. Good color palette worth reusing.

### 3. Admin Edit Mode (home.html)
Password-gated edit mode that toggles `contenteditable` on text elements. Good UX pattern.

### 4. Toast Notifications
Simple, effective 2.5s bottom-right toast. Used across all pages.

### 5. COL_MAP for Import
Smart column alias matching that handles variations like "Case Number", "CaseNumber", "case_number", "sn" etc.

### 6. 30-Second Auto-Refresh (leadership)
`setInterval(render, 30000)` — leadership dashboard refreshes every 30s for live meeting use.

### 7. Storage Event Listener
`window.addEventListener('storage', ...)` — detects changes made by other open tabs.

---

## Patterns to Fix/Improve

### 1. Unify Tower Lists
Old home.html had its own `pa_home_towers` with different structure (name + contact). Operational used `pa_towers` (name + pass). These should be ONE list.

### 2. Settings Object Structure
Old `pa_settings` in admin_console had: adminPass, adminAlias, accentColor, theme, meetingTime1, timezone1, meetingTime2, timezone2, chartsVisible, managementLabel, copyright.

Old `pa_appsettings` in dashboards had: alias, accentColor, meetingTime, timezone, chartsVisible, managementLabel.

New unified `pa_settings` must include ALL fields from both.

### 3. Default Statuses
Old files had only 4 statuses: In Progress, Pending RCA, Pending, Resolved.
We discussed 7: New, In Progress, Monitoring, Blocked, Resolved, False Alert, Suppressed.
Use the expanded set.

### 4. XLSX Parser Reliability
Old parser had incomplete deflate decompression — `defl()` function was a no-op. Need proper DecompressionStream support with fallback.

### 5. No Mobile Responsiveness
Old files had no media queries. Need proper responsive breakpoints.

### 6. Accessibility
No ARIA labels, no keyboard navigation, no focus management. Should improve.

---

## Design Reference from Old Files

### Color Palette (worth keeping)
- Accent: #1a56db (blue)
- Success: #057a55 (green)
- Warning: #b45309 (amber)
- Danger: #c81e1e (red)
- Purple: #6c2bd9
- Background light: #f5f5f3
- Surface light: #fff
- Text light: #1a1a18

### Font
Old used 'DM Sans', system-ui — clean and professional.

### Navigation
52px sticky nav bar with logo, links, connection status, theme toggle. Consistent across all pages.

### Card Pattern
Border-radius 8px, subtle shadow, left accent border on some cards. Clean and professional.
