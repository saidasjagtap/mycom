# AI Context — Operational Dashboard (IT Operations Project)

> Last updated: 2026-04-09
> Location: `C:\AI-OPS\Project AI-OPS OG`

---

## Overview

This dashboard is part of an ongoing IT Operations automation project used to track clusters, incidents, RCA, blockers, and daily updates across multiple tower teams such as VMware, Wintel, Linux, and others.

The dashboard is fully offline (no CDN, no external libraries). All data is stored in the browser's `localStorage` using the `pa_` prefix. It is a direct replacement for manual Excel-based tracking and acts as a single source of truth for both operational and management discussions.

---

## Files

| File | Purpose |
|------|---------|
| `operational_dashboard.html` | Daily use by tower leads — cluster cards, current status, change log, cases |
| `leadership_dashboard.html` | VP / Director view — metrics, charts, cluster summaries, show/hide fields |
| `admin_console.html` | Admin settings, tower management, Excel import/export wizard, template download |
| `sample_new_design.html` | Alternate design sample (dark sidebar layout) — not in active use |

---

## Daily Workflow

### 1 PM IST — Operational Call (Tower Leads)

Tower leads sign in to `operational_dashboard.html` using their tower access code and provide updates for their clusters.

Each update captures:
- Current status (what was done, what's pending, any blockers)
- Root cause analysis (RCA)
- Reasons for pending items

**Current Status behaviour:**
- Each day's update is entered in the **Current Status** field
- On the **next day**, when the page loads, the previous day's Current Status is automatically moved to the **Change Log** (auto-archive via `currentStatusDate` check in `init()`)
- A fresh Current Status can then be entered for the new day

This ensures:
- **Current Status** = today's latest update
- **Change Log** = complete chronological history

### ~5:30 PM IST (12 PM BST) — Leadership / Management Call

`leadership_dashboard.html` is used to present updates to management (VP/Director level).

Discussions cover:
- Root cause analysis
- Actions taken
- Pending blockers
- ETA and revised ETA
- Escalations and follow-ups

The management view supports **show/hide field customisation** (via Settings drawer → Detail Card — Visible Fields) so the presenter can tailor which fields appear in the cluster detail panel for each call.

---

## Data Schema — 13 Standard Fields per Cluster

| # | Field | Key | Notes |
|---|-------|-----|-------|
| 1 | SN / Case Number | `sn` | Serial or case number |
| 2 | Open Date | `openDate` | Date added to tracker (auto-set on creation) |
| 3 | ETA | `eta` | Expected resolution date |
| 4 | Extended ETA | `extEta` | If ETA was extended — **reason is required** |
| 5 | Ext. ETA Reason | `extEtaReason` | Mandatory when `extEta` is set |
| 6 | Cluster ID | `id` | Auto-assigned as `CL-<SN>` if blank |
| 7 | Issue Description | `desc` | Brief problem description |
| 8 | Config Item | `ci` | Affected system / component |
| 9 | Current Status | `currentStatus` | Today's update — auto-archives to Change Log next day |
| 10 | Change Log | `changeLog[]` | Historical updates array, auto-populated from Current Status |
| 11 | Assignment Group | `tower` | Responsible team (VMware, Wintel, Linux, etc.) |
| 12 | Final Solution | `finalSolution` | Required before marking Resolved or Closed |
| 13 | Last INC Date | `lastIncDate` | Date of most recent incident |
| — | Last INC Number | `lastIncNumber` | Latest incident/ticket reference |
| — | Status | `status` | Current state (see Status Values below) |

### 15-Column Excel Schema (export / import)

```
SN | OpenDate | ETA | ExtendedETA | ExtETAReason | ClusterID | IssueDescription |
ConfigItem | CurrentStatus | ChangeLog | AssignmentGroup | FinalSolution |
LastINCDate | LastINCNumber | Status
```

---

## Status Values (canonical — same across all pages)

| Status | Meaning |
|--------|---------|
| Work in Progress | Actively being worked |
| Pending | Waiting on something (vendor, approval, etc.) |
| Pending RCA | Root cause analysis in progress |
| Monitoring | Fix applied, under observation |
| Blocked | Blocked — needs escalation |
| Resolved | Issue resolved — Final Solution required |
| Closed | Formally closed — Final Solution required |
| False Alert | Alert raised but no actual issue |
| Suppressed | Acknowledged, intentionally suppressed |

---

## Tower Groups (default access codes)

| Tower | Code |
|-------|------|
| VMware | vmw2024 |
| Wintel | win2024 |
| Linux | lnx2024 |
| Network | net2024 |
| Database | db2024 |
| Backup | bkp2024 |
| Cloud | cld2024 |
| App | app2024 |
| Citrix | ctx2024 |
| Oracle | ora2024 |
| Splunk | splk2024 |

> Admin password default: `admin2024` — change via Admin Console → Security.

---

## Validation Rules (enforced in UI)

1. **Extended ETA requires a reason** — setting `extEta` without `extEtaReason` triggers a warning toast and red border on the reason field.
2. **Final Solution required before Resolved/Closed** — changing status to Resolved or Closed without a Final Solution shows a confirmation prompt; field shows red ⚠ Required label.
3. **Cluster ID auto-format** — if SN is `SN-2201`, Cluster ID auto-assigns as `CL-2201`. If no SN, falls back to `CL-001` style sequential.

---

## Business Logic

### Auto-Archive (Current Status → Change Log)
Runs every time `operational_dashboard.html` loads (`init()` function):
```
if currentStatus is not empty
AND currentStatusDate ≠ today
→ push currentStatus to changeLog[]
→ clear currentStatus and currentStatusDate
```

### Cluster Card Sections (operational view)
1. **Today's Update** — highlighted blue, primary daily action
2. **Identity & Status** — Status, Assignment Group, SN
3. **Timeline & Incidents** — Open Date, ETA, Last INC Date, Last INC Number (+ Extended ETA row when set)
4. **Issue Details** — Config Item, Final Solution, Issue Description
5. **Cases** — list with checkboxes, add/remove
6. **Change Log** — reverse-chronological history

### Leadership Dashboard — Field Visibility
Admin can toggle which fields appear in the cluster detail modal via:
Settings (⚙) → Detail Card — Visible Fields

Stored in `pa_settings.mgmtFields`. Default visible fields:
`id, sn, desc, tower, status, eta, extEta, extEtaReason, currentStatus, lastIncDate, lastIncNumber, finalSolution`

---

## Storage Keys (`localStorage`)

| Key | Content |
|-----|---------|
| `pa_settings` | All settings (passwords, theme, call times, mgmtFields, etc.) |
| `pa_clusters` | Array of all cluster objects |
| `pa_statuses` | Custom status list |
| `pa_towers` | Tower/team list with access codes |
| `pa_admins` | Additional admin accounts |
| `pa_account` | Account name and logos |

---

## Session Auth

- `sessionStorage` (not `localStorage`) is used for session state — survives page refresh, clears when browser is closed.
- Three roles: **Admin** (full access), **Tower Lead** (edit own tower's clusters), **View-only** (read-only).

---

## Purpose Summary

The dashboard functions as:
- A daily operational tracking system for the 1 PM tower lead call
- A communication layer between tower teams and leadership (5:30 PM call)
- A structured replacement for Excel-based cluster tracking
- A decision-support tool with both detailed (operational) and summarised (management) views
