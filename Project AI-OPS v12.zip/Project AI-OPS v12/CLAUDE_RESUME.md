# 🔁 CLAUDE RESUME FILE — Project AI-OPS OG
> **To Claude:** Read this entire file first before doing anything else. This is a continuity document. The user has picked up a fresh session and you must behave as if you already know everything below.

---

## 👤 Who You're Working With

- **Name:** quantum.agent.explorer
- **Role:** Director (IT Operations)
- **Email:** quantum.agent.explorer@gmail.com
- **Mission:** Executing a CEO-initiated vision to replace Excel-based incident tracking with a structured, **fully offline HTML dashboard system** called **"Project Automation"** for an IT Operations pilot program.
- **Key Stakeholders:**
  - VPs and Directors attend the **5:30 PM management review** (scheduled by the COO)
  - Tower Leads attend the **1 PM operational forum**

---

## 🏗️ What Has Been Built

A **five-file offline HTML dashboard system** stored locally at `C:\AI-OPS\Project AI-OPS`:

| File | Purpose |
|------|---------|
| `home.html` | Landing page / navigation hub |
| `operational_dashboard.html` | Dashboard for 1 PM tower lead forum |
| `leadership_dashboard.html` | Dashboard for 5:30 PM VP/Director management review |
| `admin_console.html` | Admin settings, import wizard, export wizard |
| `workspace/pa_workspace.js` | Shared JS logic |
| `workspace/readme.html` | Internal readme |
| `workspace/sample_cluster_data.csv` | Sample data for testing |

---

## 🔒 Architecture — Non-Negotiable Decisions

These are **locked in** and must never be reversed:

1. **Fully offline** — Zero CDN, zero external libraries, zero internet dependency. Everything is self-contained.
2. **localStorage** is the data store, using `pa_` prefix. `pa_settings` is the **single source of truth** for all configuration.
3. **Session persistence** survives page refresh but clears on browser close (by design).
4. **One cluster per row** — no auto-grouping by Cluster ID on import. Admin merges manually.
5. **One tower per cluster** — no combined/shared tower ownership.
6. **Serial numbers never skipped** in sample data; all rows use `CL-{SN}` format where Cluster ID was blank.
7. **Resolved/Closed cases excluded** from all attention flag calculations.
8. **Tower access codes hidden by default** with show/hide toggle.
9. **All-at-once file updates required** — partial or chunked delivery is explicitly rejected by the user.

---

## 🗼 Towers Covered

VMware, Wintel, Linux, Network, Database, Backup, Cloud, Windows, App, Citrix, Oracle, Splunk

---

## 📋 Data Source — Excel Tracker Fields

| Field | Notes |
|-------|-------|
| Case Number / SN | Serial number identifier |
| Cluster ID | Groups related incidents |
| Issue Description | Free text |
| Configuration Item | CI affected |
| Action Taken | What was done |
| Next Action | What's coming |
| ETA | Expected resolution |
| Extended ETA | If ETA slipped |
| Assignment Group / Tower | One tower per cluster |
| Last INC Date | Most recent incident date |
| INC Number | Incident number |
| Status | Active / Resolved / Closed |

---

## 🐛 Major Bugs Already Fixed (Don't Re-introduce)

| Bug | Root Cause | Fix Applied |
|-----|-----------|------------|
| Admin settings not propagating | Key mismatch — `pa_appsettings` vs `pa_settings` | Unified to `pa_settings` everywhere |
| Blank dashboard renders | CSS functions inside `${}` template literals caused silent JS crashes | Rewrote template literals to avoid conflict |
| Null reference crashes | `getElementById` calls targeting removed topbar elements | Removed orphan references |
| Import wizard silently failing | Relied on `parsedClusters` array that could be empty at execution time | Fixed to not depend on pre-built arrays |

---

## ✅ Features Already Built

- **4-step import wizard** in Admin Console (reads XLSX via pure JS ZIP parsing + CRC32)
- **3-step export wizard** in Admin Console
- **XLSX and CSV export buttons** on both operational and leadership dashboards
- **Offline XLSX read/write** — pure JavaScript, no external libraries

---

## 🔮 What's Next / On the Horizon

1. **Merge the two Claude project contexts** into a single unified codebase:
   - Cowork session: "Project Automation - Alpha"
   - Chat project: "Project AI-OPS OG"
2. **Continued stabilization** of the dashboard system ahead of broader pilot rollout.

---

## ⚙️ Development Principles (Critical — Follow These)

| Principle | Details |
|-----------|---------|
| **Fix all files at once** | Partial fixes in one file consistently broke others — always update all affected files simultaneously |
| **Debug localStorage independently** | Silent JS failures can make dashboards look broken even when data is fine — always verify localStorage state separately |
| **One settings key** | `pa_settings` must be used universally — never introduce a second settings key |
| **No pre-built array dependency** | Import logic must never rely on arrays that may be empty at execution time |

---

## 💬 How the User Works

- **Iterative and correction-heavy** — actively catches and directs fixes in real time
- **Strong preference** for fully offline, self-contained architecture
- **All-at-once file delivery** — never deliver partial updates
- Business context (call structure, audience, tower rules) is tightly integrated into every technical decision
- Works across **two parallel Claude environments**: Cowork (desktop) and Claude Chat

---

## 📁 Local Project Directory

```
C:\AI-OPS\Project AI-OPS\
├── home.html
├── operational_dashboard.html
├── leadership_dashboard.html
├── admin_console.html
└── workspace\
    ├── pa_workspace.js
    ├── readme.html
    └── sample_cluster_data.csv
```

---

## 🚀 How to Resume (Instructions for Claude)

1. Read this file completely ✅
2. Ask the user: *"I'm fully caught up on Project AI-OPS. What would you like to work on today?"*
3. Do NOT ask them to re-explain the project — you already know it.
4. Do NOT suggest changing any locked architecture decisions without a strong reason.
5. When making code changes, always update **all affected files simultaneously**.

---

*Last updated: 2026-04-09 | Maintained in: `C:\AI-OPS\Project AI-OPS OG\CLAUDE_RESUME.md`*
