# Developer Handover — Project Automation
**Date:** 2026-04-03
**From:** AI-Ops Build Team
**To:** Incoming Developer

---

## What You're Walking Into

This is a **fully offline HTML dashboard system** for an IT Operations pilot program. No server, no backend, no npm — just HTML files opened directly in a browser from a shared folder. All data lives in browser `localStorage`.

The CEO initiated an AI-Ops pilot. The VP built a Databricks tool that clusters repeated incident tickets. This dashboard replaces the Excel tracker the team was using, while maintaining full Excel import/export backward compatibility.

**This is a pilot account.** If it succeeds, it rolls out to every client account in the company. Senior leadership is watching.

---

## Folder Structure

```
C:\AI-OPS\Project AI-OPS\
├── home.html                  ← REBUILT (fresh) — entry point & nav hub
├── operational_dashboard.html ← OLD — needs fresh rebuild next
├── leadership_dashboard.html  ← OLD — needs fresh rebuild next
├── admin_console.html         ← OLD — needs fresh rebuild next
├── onboarding.html            ← NOT YET BUILT
├── pa-workspace/              ← OLD workspace folder
│   ├── readme.html
│   ├── pa_workspace.js
│   └── sample_cluster_data.csv
└── project_context/           ← Documentation (you are here)
    ├── PROJECT_VISION.md      ← Full business context & requirements
    ├── BUILD_PLAN.md          ← Phase-by-phase build plan with features
    ├── LESSONS_LEARNED.md     ← Critical bugs from old build — READ THIS FIRST
    └── HANDOVER.md            ← This file
```

---

## Build Status

| File | Status | Notes |
|------|--------|-------|
| home.html | **REBUILT** | Fresh build, all bugs fixed, unified pa_settings |
| operational_dashboard.html | **REBUILT** | Fresh build, multi-sheet XLSX export/import, bidirectional Updates sync |
| leadership_dashboard.html | **REBUILT** | Fresh build, read-only DSTM dashboard, multi-sheet export |
| admin_console.html | **AUDITED** | Already used pa_settings, upgraded to multi-sheet XLSX, copyright fixed |
| onboarding.html | **REBUILT** | Fresh build, roles guide, operating model, FAQ, getting started |
| sitemap.html | **REBUILT** | Full page/feature index, data model, tech stack, auth flow, daily workflow |
| workspace/ | OLD — needs rename | Currently `pa-workspace/`, should be `workspace/` |

---

## Tech Stack

Pure HTML + CSS + vanilla JavaScript. Everything inline in each file. No frameworks, no CDN, no npm. Works by double-clicking HTML files from a local folder.

---

## Architecture — How the Pages Talk

All 6 pages share data through **browser localStorage** with the `pa_` prefix. There is no backend — localStorage IS the database.

```
                   localStorage (pa_*)
                         |
    ┌────────┬───────────┼───────────┬──────────┐
    │        │           │           │          │
  home   operational  leadership   admin    onboarding
  .html   _dashboard   _dashboard  _console   .html
           .html        .html      .html
```

### Key Principle: pa_settings is the SINGLE SOURCE OF TRUTH

Every page reads settings from `pa_settings`. Admin Console is the only page that writes to it. This was the #1 bug in the old build — dashboards read from a different key and settings never synced.

---

## localStorage Keys — Complete Reference

| Key | Contains | Read By | Written By |
|-----|----------|---------|------------|
| `pa_settings` | theme, accent, copyright, adminPass, adminAlias, meetingTime1, timezone1, meetingTime2, timezone2, managementLabel, chartsVisible | ALL pages | Admin Console |
| `pa_account` | account name, companyLogo, clientLogo (base64) | ALL pages | Admin Console |
| `pa_clusters` | All cluster/case data (the main dataset) | ALL pages | Operational Dashboard, Import Wizard |
| `pa_towers` | Tower names + access codes | Home, Operational, Admin | Admin Console, Home (edit mode) |
| `pa_statuses` | Status labels + colours | Operational, Leadership, Admin | Admin Console |
| `pa_admins` | Admin user list [{alias, pass, created}] | Home, Operational, Admin | Admin Console |
| `pa_announcements` | Home page announcements | Home | Home (edit mode) |
| `pa_dashLinks` | SharePoint URLs {ops, ld, home, admin} | Home, Admin | Admin Console |
| `pa_home_content` | Editable hero text on home page | Home | Home (edit mode) |
| `pa_lastExport` | Timestamp of last workspace export | Admin | Admin Console |

### sessionStorage Keys (per-tab, clears on browser close)

| Key | Purpose | Used By |
|-----|---------|---------|
| `pa_session` | Tower/admin login session | Operational Dashboard |
| `pa_admin_session` | Admin console session | Admin Console |
| `pa_show_codes` | Tower code visibility toggle | Operational, Admin |

---

## Data Model — Cluster Object

```javascript
{
  id: 'CL-001',              // Unique cluster ID
  desc: 'Issue description',  // From Databricks / Excel
  tower: 'VMware',           // Single tower ONLY (no combos)
  status: 'In Progress',     // Must match pa_statuses labels
  ci: 'ESX-HOST-01',         // Configuration Item
  eta: '2026-04-10',         // Expected resolution date
  extEta: '',                // Extended ETA (purple display)
  inc: 'INC0041872',         // Incident number
  nextAction: 'Next step',   // What happens next
  history: [                  // Timestamped update log
    { ts: '2 Apr 2026 · 13:00', text: 'Discussed in 1PM call', author: 'Admin' }
  ],
  cases: [                    // Individual ServiceNow rows in this cluster
    { sn: '1', desc: 'Row description', ci: '', inc: '', selected: true }
  ]
}
```

**Critical rules:**
- Each Excel row = one independent cluster card (NO auto-grouping by Cluster ID)
- Single tower per cluster (never "VMware+Network")
- Admin merges clusters manually via merge mode
- History entries append with timestamps, never overwrite

---

## Authentication Flow

```
User opens page
  ├── Has pa_session in sessionStorage? → Skip login, restore session
  └── No session?
      ├── Admin tab: enter password → check against pa_settings.adminPass + pa_admins
      ├── Tower tab: select tower + enter access code → check against pa_towers
      └── View-only: no auth required (read-only access)
```

Default admin password: `admin2024` (stored in pa_settings.adminPass)

---

## Import/Export Flow

```
Excel/CSV file
  → Admin Console Import Wizard (4 steps)
    → Step 1: Upload file (.xlsx or .csv)
    → Step 2: Auto-detect + map columns (COL_ALIASES matching)
    → Step 3: Select which rows to import
    → Step 4: Choose Replace or Merge mode
  → Saved to pa_clusters in localStorage

pa_clusters
  → Export from any dashboard toolbar
  → Export Wizard in Admin Console (select clusters, columns, format)
  → Output: .xlsx (pure JS ZIP builder) or .csv
  → Legacy Excel users continue working from exported file
```

**XLSX parsing is fully offline** — uses browser `DecompressionStream` API for deflate. No external libraries.

---

## CSS Theme System

All pages use CSS custom properties with `[data-theme]` attribute on `<html>`.

```css
:root { --bg: #f5f5f3; --surface: #fff; ... }           /* Light */
[data-theme="dark"] { --bg: #0f0f0e; --surface: #1a1a18; ... }  /* Dark */
```

Theme is toggled by changing `data-theme` attribute and saving to `pa_settings.theme`.

Accent colour is injected dynamically from `pa_settings.accentColor` into `--accent`, `--accent-bg`, `--accent-border`.

---

## Non-Negotiable Rules (READ BEFORE TOUCHING ANY CODE)

### 1. Settings Key
Every page reads from `pa_settings` ONLY. Never use `pa_appsettings`, `pa_theme`, `pa_adminpass`. Those are legacy keys that caused the biggest bug in the old build (settings never synced between pages).

### 2. Template Literals + CSS Functions
NEVER put CSS functions like `blur(4px)` inside `${}` in template literals. This has crashed the entire JS twice.

```javascript
// BAD — breaks JS parser
html += `<span style="filter:${show ? 'none' : 'blur(4px)'}">`;

// GOOD — safe
var filterVal = show ? 'none' : 'blur(4px)';
html += '<span style="filter:' + filterVal + '">';
```

### 3. Element ID Audit
Before making ANY JS change, audit all `getElementById` / `querySelector` calls against actual HTML element IDs. Missing elements cause silent JS crashes.

### 4. Full Audits, Not Chunk Fixes
All pages share localStorage. Fixing one page without auditing others causes cascading failures. Always check all files before and after changes.

### 5. No Auto-Grouping
Each row in Excel/CSV = one cluster card. Never auto-group rows by Cluster ID. Admin merges manually.

### 6. Single Tower Per Cluster
No "Tower1+Tower2" combinations. One owner per cluster.

### 7. Fully Offline
No CDN, no external libraries, no npm, no internet dependency. Everything inline.

---

## Daily Call Flow (Business Context)

### 1 PM IST — Operational Call (Director-led)
- Tower leads report on assigned clusters
- Discuss: top noisy clusters, resolutions, false alerts, automation candidates
- Monitor post-resolution to confirm permanent fix
- Append timestamped updates to each cluster's history

### 5:30 PM IST — DSTM (CCO-initiated)
- Management reviews: total clusters, closures, blockers, overdue, pending actions
- Read-only leadership dashboard
- Attention flags exclude Resolved clusters

---

## Build Completion Status

1. **home.html** — REBUILT (fresh)
2. **operational_dashboard.html** — REBUILT (fresh, multi-sheet XLSX, bidirectional Updates sync)
3. **leadership_dashboard.html** — REBUILT (fresh, read-only DSTM, charts, attention flags)
4. **admin_console.html** — AUDITED (multi-sheet XLSX export, copyright fixed, no legacy keys)
5. **onboarding.html** — REBUILT (fresh, roles guide, operating model, FAQ)
6. **workspace/** — Still `pa-workspace/`, readme needs update to reflect new build

---

## Default Towers (12)

VMware, Wintel, Linux, Network, Database, Backup, Cloud, Windows, App, Citrix, Oracle, Splunk

---

## Default Statuses (7)

New, In Progress, Monitoring, Blocked, Resolved, False Alert, Suppressed

---

## Tools You'll Need

- **Any browser** (Chrome recommended for DevTools + localStorage inspection)
- **VS Code** (installed locally for editing)
- **No build tools** — just edit HTML files and refresh the browser

---

## Quick Start

1. Open `C:\AI-OPS\Project AI-OPS\home.html` in Chrome
2. Click "Admin" in nav → password: `admin2024`
3. Import data via Admin Console → Database → Import Wizard
4. Navigate between dashboards using the nav bar
5. All data persists in browser localStorage
