// ── PROJECT AUTOMATION · SHARED WORKSPACE ────────────────────────────────────
// All pages import this file. Single source of truth for all data.
// Storage key prefix: "pa_" — all keys listed below.

const PA = (() => {
  const PREFIX = 'pa_';
  const store = {
    get: k => { try { return JSON.parse(localStorage.getItem(PREFIX + k)); } catch(e) { return null; } },
    set: (k, v) => localStorage.setItem(PREFIX + k, JSON.stringify(v)),
    remove: k => localStorage.removeItem(PREFIX + k),
    keys: () => Object.keys(localStorage).filter(k => k.startsWith(PREFIX)).map(k => k.slice(PREFIX.length)),
    clear: () => PA.store.keys().forEach(k => localStorage.removeItem(PREFIX + k))
  };

  // ── DEFAULTS ──────────────────────────────────────────────────────────────
  const DEFAULTS = {
    account: { name: 'Your Account Name', companyLogo: null, clientLogo: null },
    settings: {
      adminPass: 'admin2024',
      adminAlias: 'Admin',
      accentColor: '#1a56db',
      theme: 'light',
      meetingTime1: '13:00', timezone1: 'IST',
      meetingTime2: '16:30', timezone2: 'IST',
      chartsVisible: true,
      managementLabel: 'Management',
      copyright: 'Created by Smallbox'
    },
    towers: [
      { name: 'VMware', pass: 'vmw2024' },
      { name: 'Wintel', pass: 'win2024' },
      { name: 'Linux', pass: 'lnx2024' },
      { name: 'Network', pass: 'net2024' },
      { name: 'Database', pass: 'db2024' },
      { name: 'Backup', pass: 'bkp2024' },
      { name: 'Cloud', pass: 'cld2024' },
      { name: 'Windows', pass: 'win2024' },
      { name: 'App', pass: 'app2024' },
      { name: 'Citrix', pass: 'ctx2024' },
      { name: 'Oracle', pass: 'ora2024' },
      { name: 'Splunk', pass: 'splk2024' }
    ],
    statuses: [
      { label: 'In Progress', color: '#1a56db', bg: '#eff4ff' },
      { label: 'Pending RCA', color: '#6c2bd9', bg: '#f5f3ff' },
      { label: 'Pending',     color: '#b45309', bg: '#fffbeb' },
      { label: 'Resolved',   color: '#057a55', bg: '#e3faf0' }
    ],
    clusters: null,
    announcements: [],
    dashLinks: { ops: '', ld: '', home: '', admin: '' },
    admins: [{ alias: 'Admin', pass: 'admin2024', created: new Date().toISOString() }]
  };

  // ── GETTERS / SETTERS ─────────────────────────────────────────────────────
  const get = (key) => store.get(key) ?? DEFAULTS[key] ?? null;
  const set = (key, val) => store.set(key, val);
  const remove = (key) => store.remove(key);

  // ── WORKSPACE EXPORT (entire DB as JSON) ──────────────────────────────────
  const exportWorkspace = () => {
    const data = {};
    store.keys().forEach(k => { data[k] = store.get(k); });
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = 'pa_workspace_' + new Date().toISOString().slice(0, 10) + '.json';
    a.click();
  };

  // ── WORKSPACE IMPORT ──────────────────────────────────────────────────────
  const importWorkspace = (jsonText) => {
    const data = JSON.parse(jsonText);
    Object.entries(data).forEach(([k, v]) => store.set(k, v));
  };

  // ── CONNECTION STATUS ─────────────────────────────────────────────────────
  const getStatus = () => {
    const clusters = get('clusters');
    const account = get('account');
    return {
      hasData: clusters !== null && clusters.length > 0,
      clusterCount: clusters ? clusters.length : 0,
      accountName: account ? account.name : 'Not configured',
      lastExport: store.get('lastExport') || null
    };
  };

  // ── THEME HELPERS ─────────────────────────────────────────────────────────
  const applyTheme = () => {
    const s = get('settings') || DEFAULTS.settings;
    document.documentElement.setAttribute('data-theme', s.theme || 'light');
    if (s.accentColor) {
      const hex = s.accentColor;
      const r = parseInt(hex.slice(1,3),16), g = parseInt(hex.slice(3,5),16), b = parseInt(hex.slice(5,7),16);
      document.documentElement.style.setProperty('--accent', hex);
      document.documentElement.style.setProperty('--accent-bg', `rgba(${r},${g},${b},.1)`);
      document.documentElement.style.setProperty('--accent-border', `rgba(${r},${g},${b},.35)`);
    }
    const btn = document.getElementById('themeBtn');
    if (btn) btn.textContent = (s.theme === 'dark') ? '☀️' : '🌙';
  };

  const toggleTheme = () => {
    const s = get('settings') || DEFAULTS.settings;
    s.theme = s.theme === 'dark' ? 'light' : 'dark';
    set('settings', s);
    applyTheme();
  };

  // ── LOGO HELPERS ──────────────────────────────────────────────────────────
  const applyLogos = () => {
    const a = get('account') || DEFAULTS.account;
    const companyPl = document.getElementById('companyLogoPlaceholder');
    const companyImg = document.getElementById('companyLogoImg');
    const clientImg = document.getElementById('clientLogoImg');
    const divider = document.getElementById('clientLogoDivider');
    if (companyImg && a.companyLogo) { companyImg.src = a.companyLogo; companyImg.style.display = 'block'; if(companyPl) companyPl.style.display = 'none'; }
    else { if(companyImg) companyImg.style.display = 'none'; if(companyPl) companyPl.style.display = 'flex'; }
    if (clientImg && a.clientLogo) { clientImg.src = a.clientLogo; clientImg.style.display = 'block'; if(divider) divider.style.display = 'block'; }
    else { if(clientImg) clientImg.style.display = 'none'; if(divider) divider.style.display = 'none'; }
  };

  // ── NAV BAR BUILDER ───────────────────────────────────────────────────────
  const buildNav = (activePage) => {
    const status = getStatus();
    const s = get('settings') || DEFAULTS.settings;
    const links = get('dashLinks') || DEFAULTS.dashLinks;
    const pages = [
      { id: 'home', label: 'Home', url: links.home || 'home.html', icon: '⌂' },
      { id: 'ld', label: 'Leadership', url: links.ld || 'leadership_dashboard.html', icon: '◈' },
      { id: 'ops', label: 'Operational', url: links.ops || 'operational_dashboard.html', icon: '◧' },
      { id: 'admin', label: 'Admin Console', url: links.admin || 'admin_console.html', icon: '⚙' },
      { id: 'workspace', label: 'Workspace', url: 'workspace/readme.html', icon: '⊞' }
    ];
    const navLinks = pages.map(p => `
      <a href="${p.url}" class="nav-link${p.id === activePage ? ' active' : ''}" title="${p.label}">
        <span class="nav-icon">${p.icon}</span>
        <span class="nav-label">${p.label}</span>
      </a>`).join('');
    const statusDot = status.hasData
      ? `<span class="conn-dot conn-ok" title="${status.clusterCount} clusters loaded"></span>`
      : `<span class="conn-dot conn-warn" title="No data loaded"></span>`;
    return `
      <nav class="pa-nav">
        <div class="nav-brand">
          <div class="nav-logo-wrap">
            <div class="logo-placeholder nav-logo-placeholder" id="companyLogoPlaceholder">
              <svg width="14" height="14" viewBox="0 0 24 24" fill="white"><path d="M3 3h7v7H3zm11 0h7v7h-7zM3 14h7v7H3zm11 3h2v-2h2v2h2v2h-2v2h-2v-2h-2z"/></svg>
            </div>
            <img id="companyLogoImg" style="display:none;height:28px;width:auto;max-width:80px;object-fit:contain;border-radius:4px;"/>
          </div>
          <div class="nav-brand-text">
            <div class="nav-brand-name">Project Automation</div>
            <div class="nav-brand-sub" id="navAccountName">${status.accountName}</div>
          </div>
        </div>
        <div class="nav-links">${navLinks}</div>
        <div class="nav-right">
          <div class="conn-status">${statusDot}<span class="conn-label">${status.hasData ? status.clusterCount + ' clusters' : 'No data'}</span></div>
          <button class="nav-btn" id="themeBtn" onclick="PA.toggleTheme()" title="Toggle theme">🌙</button>
        </div>
      </nav>`;
  };

  const NAV_CSS = `
    .pa-nav{background:var(--surface);border-bottom:1px solid var(--border);padding:0 20px;display:flex;align-items:center;gap:0;height:52px;position:sticky;top:0;z-index:200;}
    .nav-brand{display:flex;align-items:center;gap:9px;margin-right:20px;min-width:180px;}
    .nav-logo-wrap{flex-shrink:0;}
    .nav-logo-placeholder{width:28px;height:28px;background:var(--accent);border-radius:7px;display:flex;align-items:center;justify-content:center;}
    .nav-brand-name{font-size:13px;font-weight:700;color:var(--text);letter-spacing:-.01em;}
    .nav-brand-sub{font-size:10px;color:var(--text3);}
    .nav-links{display:flex;align-items:center;gap:2px;flex:1;}
    .nav-link{display:flex;align-items:center;gap:5px;padding:5px 11px;border-radius:var(--r);font-size:12px;font-weight:500;color:var(--text2);text-decoration:none;transition:all .15s;white-space:nowrap;}
    .nav-link:hover{background:var(--surface2);color:var(--text);}
    .nav-link.active{background:var(--accent-bg);color:var(--accent);font-weight:600;}
    .nav-icon{font-size:13px;}
    .nav-right{display:flex;align-items:center;gap:8px;margin-left:auto;}
    .conn-status{display:flex;align-items:center;gap:5px;}
    .conn-dot{width:7px;height:7px;border-radius:50%;}
    .conn-ok{background:#22c55e;}
    .conn-warn{background:#f59e0b;}
    .conn-label{font-size:11px;color:var(--text3);}
    .nav-btn{width:30px;height:30px;border-radius:var(--r);border:1px solid var(--border2);background:var(--surface2);cursor:pointer;font-size:13px;display:flex;align-items:center;justify-content:center;}
    .nav-btn:hover{background:var(--surface3);}
  `;

  return { store, get, set, remove, exportWorkspace, importWorkspace, getStatus, applyTheme, toggleTheme, applyLogos, buildNav, NAV_CSS, DEFAULTS };
})();
